# SmartStudy AI

A real, working AI study assistant: Next.js 14 (App Router) + TypeScript + Tailwind +
Supabase (auth & DB) + Gemini API (AI features) + Stripe (billing).

## 1. Setup (required before anything works)

```bash
npm install
cp .env.local.example .env.local
```

Fill in `.env.local`:

| Variable | Where to get it |
|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` / `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Supabase project → Settings → API |
| `SUPABASE_SERVICE_ROLE_KEY` | Same page, "service_role" key (server-only, never expose client-side) |
| `GEMINI_API_KEY` | https://aistudio.google.com/app/apikey |
| `STRIPE_SECRET_KEY` / `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY` | Stripe dashboard → Developers → API keys |
| `NEXT_PUBLIC_STRIPE_PRO_PRICE_ID` | Stripe dashboard → Product catalog → create a recurring "Pro" price |
| `STRIPE_WEBHOOK_SECRET` | `stripe listen --forward-to localhost:3000/api/stripe/webhook` prints this locally |

### Database
In the Supabase SQL editor, run `supabase/schema.sql` once. It creates every table, enables
Row Level Security so users can only ever read/write their own rows, and adds a trigger that
creates a `profiles` row automatically on signup.

### Google login
In Supabase → Authentication → Providers → Google, add your Google OAuth client ID/secret, and
set the redirect URL to `https://<your-domain>/auth/callback` (and
`http://localhost:3000/auth/callback` for local dev).

### Run it
```bash
npm run dev
```

## 2. Manual test flow (do this once end-to-end)

1. **Sign up** at `/signup` with a real email → check inbox → click confirmation link
   (or disable email confirmation in Supabase Auth settings for faster local testing).
2. **Log in** at `/login` → you land on `/dashboard` with real (zeroed) stats.
3. **Forgot password**: from `/login`, click "Forgot password?", submit your email, open the
   emailed link, set a new password on `/reset-password`, confirm you're redirected in.
4. **Google login**: click "Continue with Google" on `/login` or `/signup`, complete the OAuth
   flow, confirm you land on `/dashboard`.
5. **Study Planner**: `/dashboard/planner` → enter subjects/goal/exam date/hours → Generate →
   confirm a real day-by-day table appears → Save → confirm it appears under "Saved plans".
6. **Notes Summarizer**: `/dashboard/notes` → paste a paragraph of notes → Generate → confirm
   summary/key points/revision notes appear → Save → confirm it's listed below.
7. **Quiz Generator**: `/dashboard/quiz` → enter a topic → Generate → answer every question →
   Submit → confirm score is calculated correctly → Save → confirm it's in "Past attempts".
8. **Flashcards**: `/dashboard/flashcards` → enter a topic → Generate → click cards to flip →
   Save deck → confirm it's listed under "Saved decks" and expandable.
9. **Dashboard overview**: return to `/dashboard`, confirm the stat counts and average quiz
   score reflect what you just created (no hardcoded numbers).
10. **Subscription**: `/dashboard/subscription` → click "Upgrade to Pro" → confirm real redirect
    to Stripe Checkout (test mode) → complete with Stripe test card `4242 4242 4242 4242` →
    confirm webhook flips your `profiles.plan` to `pro` (requires `stripe listen` running
    locally, or a configured webhook endpoint in production).
11. **Logout**: click "Sign out" in the sidebar → confirm redirect to `/login` and that
    `/dashboard` now redirects you back to `/login` if visited directly.

## 3. Deploying to Vercel

1. Push this repo to GitHub.
2. Import it in Vercel → set all the same env vars from `.env.local` in Project Settings →
   Environment Variables.
3. Set `NEXT_PUBLIC_SITE_URL` to your production URL.
4. Add `https://<your-domain>/auth/callback` as an additional redirect URL in Supabase Auth
   settings.
5. Create a production Stripe webhook endpoint pointing to
   `https://<your-domain>/api/stripe/webhook`, subscribed to `checkout.session.completed`,
   `customer.subscription.updated`, `customer.subscription.deleted`; copy its signing secret into
   `STRIPE_WEBHOOK_SECRET`.
6. Deploy.

## 4. Honest status checklist

Everything below is real, connected code — not mockups. What I could and couldn't verify from
this sandbox, specifically:

✅ **Verified by code review / static reasoning** (I read every file back carefully):
- Every button has a real `onClick`/`onSubmit` handler wired to a real function — none are
  no-ops or decorative.
- Every AI feature (Planner, Summarizer, Quiz, Flashcards) has: a form → a POST to a real
  `/api/ai/*` route → an authenticated Gemini call → JSON parsing with error handling → a
  distinct loading, error, and success state in the UI → a save action that writes to Supabase.
- Auth covers signup, login, logout, Google OAuth, forgot/reset password, session-aware
  middleware, and a server-protected dashboard layout (double-checked: middleware redirects
  AND the layout re-checks `auth.getUser()` server-side).
- Every table has Row Level Security scoped to `auth.uid()`, so users cannot read or write each
  other's data even if the API is called directly.
- The dashboard overview queries real row counts and computes the real average quiz score —
  there are no hardcoded numbers.
- Stripe checkout creates a real Checkout Session and only marks a user "pro" via a signature-
  verified webhook — there is no fake "payment succeeded" path anywhere.
- Every API route rejects unauthenticated requests (401) and returns real error messages on
  Gemini/Stripe/Supabase failures instead of pretending to succeed.

⚠️ **Could not verify by actually running the app**, because this sandbox has no outbound
network access (no `npm install`, no live Supabase/Gemini/Stripe calls, no `next build`,
no deployment):
- I have not run `npm run build` or `npm run dev` against this code, so a typo or a version-
  specific API mismatch in a dependency (Next 14.2.5, `@supabase/ssr` 0.5.x, Stripe 16.x, or
  `@google/generative-ai` 0.19.x) is possible, even though the patterns used match each
  library's documented API as of my knowledge.
- I have not exercised a live signup → login → AI generation → save → logout flow against a
  real Supabase project, Gemini key, or Stripe test mode.
- I have not deployed this to Vercel.

**What I'd ask you to do**: run `npm install && npm run dev` locally with your keys filled in,
walk through the 11-step test flow in section 2, and tell me the first thing that breaks (paste
the error). I'll fix it immediately — I'd rather you catch a real bug on a real run than take my
word for a build I never executed.

## 5. Project structure

```
app/
  (auth)/login, signup, forgot-password, reset-password   — auth pages
  auth/callback/route.ts                                   — OAuth/email confirm handler
  dashboard/                                                — protected app (layout + 6 pages)
  api/ai/{planner,summarize,quiz,flashcards}/route.ts       — Gemini-backed endpoints
  api/stripe/{checkout,webhook}/route.ts                    — billing
  api/auth/signout/route.ts
lib/supabase/{client,server}.ts                             — browser + server + admin clients
lib/gemini.ts                                                — Gemini wrapper w/ JSON parsing
supabase/schema.sql                                          — full DB schema + RLS
types/database.ts                                             — shared TS types
```
