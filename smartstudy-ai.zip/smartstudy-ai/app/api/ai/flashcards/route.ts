import { NextResponse } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { generateJSON, GeminiConfigError, GeminiGenerationError } from "@/lib/gemini";
import type { Flashcard } from "@/types/database";

export async function POST(request: Request) {
  try {
    const supabase = createServerSupabaseClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      return NextResponse.json({ error: "You must be logged in." }, { status: 401 });
    }

    const { input, numCards } = (await request.json()) as { input: string; numCards: number };

    if (!input || input.trim().length < 3) {
      return NextResponse.json(
        { error: "Please enter a topic or paste notes (at least 3 characters)." },
        { status: 400 }
      );
    }

    const count = Math.min(Math.max(numCards || 10, 4), 30);

    const prompt = `You are a flashcard generator for students. Create ${count} flashcards from this topic or notes:

"""
${input.slice(0, 8000)}
"""

Return ONLY valid JSON (no markdown fences) matching exactly this shape:
{
  "cards": [
    { "front": "a concise question or term", "back": "a concise answer or definition" }
  ]
}

Generate exactly ${count} cards. Keep each side under 25 words.`;

    let parsed: { cards: Flashcard[] };
    try {
      parsed = await generateJSON(prompt);
    } catch (err) {
      if (err instanceof GeminiConfigError) {
        return NextResponse.json({ error: err.message }, { status: 500 });
      }
      if (err instanceof GeminiGenerationError) {
        return NextResponse.json({ error: err.message }, { status: 502 });
      }
      throw err;
    }

    const isValid =
      Array.isArray(parsed.cards) &&
      parsed.cards.length > 0 &&
      parsed.cards.every((c) => typeof c.front === "string" && typeof c.back === "string");

    if (!isValid) {
      return NextResponse.json(
        { error: "The AI returned malformed flashcards. Please try again." },
        { status: 502 }
      );
    }

    return NextResponse.json({ cards: parsed.cards });
  } catch (err) {
    console.error("Flashcards route error:", err);
    return NextResponse.json({ error: "Unexpected server error." }, { status: 500 });
  }
}
