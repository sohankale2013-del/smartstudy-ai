import { NextResponse } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { generateJSON, GeminiConfigError, GeminiGenerationError } from "@/lib/gemini";
import type { StudyScheduleDay } from "@/types/database";

export async function POST(request: Request) {
  try {
    const supabase = createServerSupabaseClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      return NextResponse.json({ error: "You must be logged in." }, { status: 401 });
    }

    const body = await request.json();
    const { subjects, goal, examDate, hoursPerDay } = body as {
      subjects: string[];
      goal: string;
      examDate: string;
      hoursPerDay: number;
    };

    if (!subjects?.length || !goal || !examDate || !hoursPerDay) {
      return NextResponse.json(
        { error: "subjects, goal, examDate, and hoursPerDay are all required." },
        { status: 400 }
      );
    }

    const today = new Date().toISOString().slice(0, 10);
    const prompt = `You are an expert study coach. Create a day-by-day study schedule.

Subjects: ${subjects.join(", ")}
Goal: ${goal}
Exam date: ${examDate}
Available study hours per day: ${hoursPerDay}
Today's date: ${today}

Return ONLY valid JSON (no markdown fences) matching exactly this shape:
{
  "schedule": [
    { "date": "YYYY-MM-DD", "subject": "string", "topic": "string", "duration_minutes": number, "notes": "string" }
  ]
}

Rules:
- Cover every day from today until the exam date (inclusive), skip no days.
- Rotate subjects sensibly, prioritizing weaker or harder topics earlier.
- Total daily duration_minutes across all entries for a given date should not exceed ${hoursPerDay * 60} minutes.
- Keep "notes" short and actionable (max 15 words).`;

    let parsed: { schedule: StudyScheduleDay[] };
    try {
      parsed = await generateJSON<{ schedule: StudyScheduleDay[] }>(prompt);
    } catch (err) {
      if (err instanceof GeminiConfigError) {
        return NextResponse.json({ error: err.message }, { status: 500 });
      }
      if (err instanceof GeminiGenerationError) {
        return NextResponse.json({ error: err.message }, { status: 502 });
      }
      throw err;
    }

    if (!Array.isArray(parsed.schedule)) {
      return NextResponse.json(
        { error: "The AI response was malformed. Please try again." },
        { status: 502 }
      );
    }

    return NextResponse.json({ schedule: parsed.schedule });
  } catch (err) {
    console.error("Planner route error:", err);
    return NextResponse.json({ error: "Unexpected server error." }, { status: 500 });
  }
}
