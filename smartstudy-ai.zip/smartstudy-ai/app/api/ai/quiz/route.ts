import { NextResponse } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { generateJSON, GeminiConfigError, GeminiGenerationError } from "@/lib/gemini";
import type { MCQQuestion } from "@/types/database";

export async function POST(request: Request) {
  try {
    const supabase = createServerSupabaseClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      return NextResponse.json({ error: "You must be logged in." }, { status: 401 });
    }

    const { topic, numQuestions } = (await request.json()) as {
      topic: string;
      numQuestions: number;
    };

    if (!topic || topic.trim().length < 3) {
      return NextResponse.json(
        { error: "Please enter a topic or paste some notes (at least 3 characters)." },
        { status: 400 }
      );
    }

    const count = Math.min(Math.max(numQuestions || 5, 3), 15);

    const prompt = `You are a quiz generator for students. Create ${count} multiple-choice questions based on this topic or notes:

"""
${topic.slice(0, 8000)}
"""

Return ONLY valid JSON (no markdown fences) matching exactly this shape:
{
  "questions": [
    {
      "question": "string",
      "options": ["string", "string", "string", "string"],
      "correct_index": number,
      "explanation": "string"
    }
  ]
}

Rules:
- Exactly 4 options per question.
- correct_index is 0-based and must point to the correct option.
- explanation is a 1-2 sentence reason the correct answer is right.
- Generate exactly ${count} questions.`;

    let parsed: { questions: MCQQuestion[] };
    try {
      parsed = await generateJSON(prompt);
    } catch (err) {
      if (err instanceof GeminiConfigError) {
        return NextResponse.json({ error: err.message }, { status: 500 });
      }
      if (err instanceof GeminiGenerationError) {
        return NextResponse.json({ error: err.message }, { status: 502 });
      }
      throw err;
    }

    const questions = parsed.questions;
    const isValid =
      Array.isArray(questions) &&
      questions.length > 0 &&
      questions.every(
        (q) =>
          typeof q.question === "string" &&
          Array.isArray(q.options) &&
          q.options.length === 4 &&
          typeof q.correct_index === "number" &&
          q.correct_index >= 0 &&
          q.correct_index < 4
      );

    if (!isValid) {
      return NextResponse.json(
        { error: "The AI returned a malformed quiz. Please try again." },
        { status: 502 }
      );
    }

    return NextResponse.json({ questions, topic });
  } catch (err) {
    console.error("Quiz route error:", err);
    return NextResponse.json({ error: "Unexpected server error." }, { status: 500 });
  }
}
