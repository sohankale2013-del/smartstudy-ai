import { NextResponse } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { generateJSON, GeminiConfigError, GeminiGenerationError } from "@/lib/gemini";

export async function POST(request: Request) {
  try {
    const supabase = createServerSupabaseClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      return NextResponse.json({ error: "You must be logged in." }, { status: 401 });
    }

    const { notes } = (await request.json()) as { notes: string };

    if (!notes || notes.trim().length < 20) {
      return NextResponse.json(
        { error: "Please paste at least a few sentences of notes." },
        { status: 400 }
      );
    }

    const prompt = `You are a study assistant. Summarize the following notes for a student.

Notes:
"""
${notes.slice(0, 12000)}
"""

Return ONLY valid JSON (no markdown fences) matching exactly this shape:
{
  "summary": "a concise 3-5 sentence summary",
  "key_points": ["short bullet point", "..."],
  "revision_notes": ["a compact revision-ready statement", "..."]
}

Include at least 3 key_points and at least 3 revision_notes.`;

    let parsed: { summary: string; key_points: string[]; revision_notes: string[] };
    try {
      parsed = await generateJSON(prompt);
    } catch (err) {
      if (err instanceof GeminiConfigError) {
        return NextResponse.json({ error: err.message }, { status: 500 });
      }
      if (err instanceof GeminiGenerationError) {
        return NextResponse.json({ error: err.message }, { status: 502 });
      }
      throw err;
    }

    if (!parsed.summary || !Array.isArray(parsed.key_points) || !Array.isArray(parsed.revision_notes)) {
      return NextResponse.json(
        { error: "The AI response was malformed. Please try again." },
        { status: 502 }
      );
    }

    return NextResponse.json(parsed);
  } catch (err) {
    console.error("Summarize route error:", err);
    return NextResponse.json({ error: "Unexpected server error." }, { status: 500 });
  }
}
