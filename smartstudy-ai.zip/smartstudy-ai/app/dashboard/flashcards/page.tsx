"use client";

import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import FlashcardView from "@/components/FlashcardView";
import type { Flashcard, FlashcardDeck } from "@/types/database";

export default function FlashcardsPage() {
  const [input, setInput] = useState("");
  const [numCards, setNumCards] = useState(10);
  const [title, setTitle] = useState("");

  const [cards, setCards] = useState<Flashcard[] | null>(null);
  const [generating, setGenerating] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [saveMessage, setSaveMessage] = useState<string | null>(null);

  const [decks, setDecks] = useState<FlashcardDeck[]>([]);
  const [loadingDecks, setLoadingDecks] = useState(true);
  const [activeDeck, setActiveDeck] = useState<FlashcardDeck | null>(null);

  async function loadDecks() {
    setLoadingDecks(true);
    const supabase = createClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return;

    const { data } = await supabase
      .from("flashcard_decks")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false });

    if (data) setDecks(data as FlashcardDeck[]);
    setLoadingDecks(false);
  }

  useEffect(() => {
    loadDecks();
  }, []);

  async function handleGenerate() {
    setError(null);
    setSaveMessage(null);
    setCards(null);

    if (input.trim().length < 3) {
      setError("Please enter a topic or paste some notes.");
      return;
    }

    setGenerating(true);
    try {
      const res = await fetch("/api/ai/flashcards", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ input, numCards }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Failed to generate flashcards.");
        return;
      }
      setCards(data.cards);
      if (!title) setTitle(input.slice(0, 40));
    } catch (err) {
      setError("Network error. Please check your connection and try again.");
    } finally {
      setGenerating(false);
    }
  }

  async function handleSave() {
    if (!cards) return;
    if (!title.trim()) {
      setError("Please give this deck a title before saving.");
      return;
    }
    setSaving(true);
    setSaveMessage(null);
    setError(null);

    try {
      const supabase = createClient();
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) {
        setError("You must be logged in to save.");
        return;
      }

      const { error: insertError } = await supabase.from("flashcard_decks").insert({
        user_id: user.id,
        title: title.trim(),
        cards,
      });

      if (insertError) {
        setError(insertError.message);
        return;
      }

      setSaveMessage("Deck saved successfully.");
      await loadDecks();
    } catch (err) {
      setError("Failed to save. Please try again.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-900">AI Flashcards</h1>
      <p className="mt-1 text-sm text-gray-500">
        Generate a flashcard deck from any topic or your own notes. Click a card to flip it.
      </p>

      <div className="card mt-6 space-y-4">
        <div>
          <label className="mb-1 block text-sm font-medium text-gray-700">Topic or notes</label>
          <textarea
            className="input-field h-28 resize-none"
            placeholder="e.g. Spanish vocabulary for travel, cell biology terms"
            value={input}
            onChange={(e) => setInput(e.target.value)}
          />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="mb-1 block text-sm font-medium text-gray-700"># of cards</label>
            <input
              type="number"
              min={4}
              max={30}
              className="input-field"
              value={numCards}
              onChange={(e) => setNumCards(parseInt(e.target.value, 10))}
            />
          </div>
          <div>
            <label className="mb-1 block text-sm font-medium text-gray-700">Deck title</label>
            <input
              className="input-field"
              placeholder="e.g. Cell Biology Basics"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
          </div>
        </div>
        {error && (
          <div className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700" role="alert">
            {error}
          </div>
        )}
        <button onClick={handleGenerate} disabled={generating} className="btn-primary">
          {generating ? "Generating flashcards..." : "Generate flashcards"}
        </button>
      </div>

      {cards && (
        <div className="mt-6">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="font-semibold text-gray-900">{title || "Untitled deck"}</h2>
            <button onClick={handleSave} disabled={saving} className="btn-primary">
              {saving ? "Saving..." : "Save deck"}
            </button>
          </div>
          {saveMessage && (
            <div className="mb-4 rounded-lg bg-green-50 px-3 py-2 text-sm text-green-700">
              {saveMessage}
            </div>
          )}
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {cards.map((card, i) => (
              <FlashcardView key={i} card={card} />
            ))}
          </div>
        </div>
      )}

      <div className="mt-10">
        <h2 className="mb-3 text-lg font-semibold text-gray-900">Saved decks</h2>
        {loadingDecks ? (
          <p className="text-sm text-gray-500">Loading...</p>
        ) : decks.length === 0 ? (
          <p className="text-sm text-gray-500">No saved decks yet.</p>
        ) : (
          <div className="space-y-3">
            {decks.map((deck) => (
              <div key={deck.id} className="card">
                <button
                  onClick={() => setActiveDeck(activeDeck?.id === deck.id ? null : deck)}
                  className="flex w-full items-center justify-between text-left"
                >
                  <span className="font-medium text-gray-900">{deck.title}</span>
                  <span className="text-xs text-gray-400">{deck.cards.length} cards</span>
                </button>
                {activeDeck?.id === deck.id && (
                  <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
                    {deck.cards.map((card, i) => (
                      <FlashcardView key={i} card={card} />
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
