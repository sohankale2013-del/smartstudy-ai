"use client";

import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import type { NotesSummary } from "@/types/database";

export default function NotesPage() {
  const [notes, setNotes] = useState("");
  const [result, setResult] = useState<{
    summary: string;
    key_points: string[];
    revision_notes: string[];
  } | null>(null);

  const [generating, setGenerating] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [saveMessage, setSaveMessage] = useState<string | null>(null);

  const [saved, setSaved] = useState<NotesSummary[]>([]);
  const [loadingSaved, setLoadingSaved] = useState(true);

  async function loadSaved() {
    setLoadingSaved(true);
    const supabase = createClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return;

    const { data } = await supabase
      .from("notes_summaries")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false });

    if (data) setSaved(data as NotesSummary[]);
    setLoadingSaved(false);
  }

  useEffect(() => {
    loadSaved();
  }, []);

  async function handleGenerate() {
    setError(null);
    setSaveMessage(null);
    setResult(null);

    if (notes.trim().length < 20) {
      setError("Please paste at least a few sentences of notes.");
      return;
    }

    setGenerating(true);
    try {
      const res = await fetch("/api/ai/summarize", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ notes }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Failed to summarize notes.");
        return;
      }
      setResult(data);
    } catch (err) {
      setError("Network error. Please check your connection and try again.");
    } finally {
      setGenerating(false);
    }
  }

  async function handleSave() {
    if (!result) return;
    setSaving(true);
    setSaveMessage(null);
    setError(null);
    try {
      const supabase = createClient();
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) {
        setError("You must be logged in to save.");
        return;
      }

      const { error: insertError } = await supabase.from("notes_summaries").insert({
        user_id: user.id,
        original_notes: notes,
        summary: result.summary,
        key_points: result.key_points,
        revision_notes: result.revision_notes,
      });

      if (insertError) {
        setError(insertError.message);
        return;
      }

      setSaveMessage("Summary saved successfully.");
      await loadSaved();
    } catch (err) {
      setError("Failed to save. Please try again.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-900">AI Notes Summarizer</h1>
      <p className="mt-1 text-sm text-gray-500">
        Paste your notes below and get a summary, key points, and revision notes.
      </p>

      <div className="card mt-6">
        <textarea
          className="input-field h-48 resize-none"
          placeholder="Paste your notes here..."
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
        />
        {error && (
          <div className="mt-3 rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700" role="alert">
            {error}
          </div>
        )}
        <button onClick={handleGenerate} disabled={generating} className="btn-primary mt-4">
          {generating ? "Summarizing..." : "Generate summary"}
        </button>
      </div>

      {result && (
        <div className="card mt-6">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="font-semibold text-gray-900">Result</h2>
            <button onClick={handleSave} disabled={saving} className="btn-primary">
              {saving ? "Saving..." : "Save"}
            </button>
          </div>
          {saveMessage && (
            <div className="mb-4 rounded-lg bg-green-50 px-3 py-2 text-sm text-green-700">
              {saveMessage}
            </div>
          )}
          <SummaryView data={result} />
        </div>
      )}

      <div className="mt-8">
        <h2 className="mb-3 text-lg font-semibold text-gray-900">Saved summaries</h2>
        {loadingSaved ? (
          <p className="text-sm text-gray-500">Loading...</p>
        ) : saved.length === 0 ? (
          <p className="text-sm text-gray-500">No saved summaries yet.</p>
        ) : (
          <div className="space-y-4">
            {saved.map((item) => (
              <details key={item.id} className="card">
                <summary className="cursor-pointer font-medium text-gray-900">
                  {item.summary.slice(0, 80)}
                  {item.summary.length > 80 ? "..." : ""}
                </summary>
                <div className="mt-4">
                  <SummaryView data={item} />
                </div>
              </details>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function SummaryView({
  data,
}: {
  data: { summary: string; key_points: string[]; revision_notes: string[] };
}) {
  return (
    <div className="space-y-4">
      <div>
        <h3 className="mb-1 text-sm font-semibold text-gray-700">Summary</h3>
        <p className="text-sm text-gray-600">{data.summary}</p>
      </div>
      <div>
        <h3 className="mb-1 text-sm font-semibold text-gray-700">Key points</h3>
        <ul className="list-inside list-disc text-sm text-gray-600">
          {data.key_points.map((point, i) => (
            <li key={i}>{point}</li>
          ))}
        </ul>
      </div>
      <div>
        <h3 className="mb-1 text-sm font-semibold text-gray-700">Revision notes</h3>
        <ul className="list-inside list-disc text-sm text-gray-600">
          {data.revision_notes.map((point, i) => (
            <li key={i}>{point}</li>
          ))}
        </ul>
      </div>
    </div>
  );
}
