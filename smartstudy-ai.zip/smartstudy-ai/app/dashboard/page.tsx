import Link from "next/link";
import { createServerSupabaseClient } from "@/lib/supabase/server";

export const dynamic = "force-dynamic";

export default async function DashboardOverview() {
  const supabase = createServerSupabaseClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) return null;

  const [plansRes, notesRes, quizzesRes, attemptsRes, decksRes] = await Promise.all([
    supabase.from("study_plans").select("id", { count: "exact", head: true }).eq("user_id", user.id),
    supabase.from("notes_summaries").select("id", { count: "exact", head: true }).eq("user_id", user.id),
    supabase.from("quizzes").select("id", { count: "exact", head: true }).eq("user_id", user.id),
    supabase.from("quiz_attempts").select("score, total").eq("user_id", user.id),
    supabase.from("flashcard_decks").select("id", { count: "exact", head: true }).eq("user_id", user.id),
  ]);

  const attempts = attemptsRes.data ?? [];
  const avgScorePct =
    attempts.length > 0
      ? Math.round(
          (attempts.reduce((sum, a) => sum + a.score / a.total, 0) / attempts.length) * 100
        )
      : null;

  const stats = [
    { label: "Study Plans", value: plansRes.count ?? 0, href: "/dashboard/planner" },
    { label: "Notes Summarized", value: notesRes.count ?? 0, href: "/dashboard/notes" },
    { label: "Quizzes Created", value: quizzesRes.count ?? 0, href: "/dashboard/quiz" },
    { label: "Flashcard Decks", value: decksRes.count ?? 0, href: "/dashboard/flashcards" },
  ];

  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-900">Welcome back</h1>
      <p className="mt-1 text-sm text-gray-500">Here's what's happening in your account.</p>

      <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => (
          <Link key={stat.label} href={stat.href} className="card transition hover:shadow-md">
            <p className="text-sm text-gray-500">{stat.label}</p>
            <p className="mt-2 text-3xl font-bold text-gray-900">{stat.value}</p>
          </Link>
        ))}
      </div>

      <div className="mt-6 card">
        <p className="text-sm text-gray-500">Average Quiz Score</p>
        <p className="mt-2 text-3xl font-bold text-gray-900">
          {avgScorePct === null ? "—" : `${avgScorePct}%`}
        </p>
        <p className="mt-1 text-xs text-gray-400">
          {attempts.length === 0
            ? "Take a quiz to see your average score here."
            : `Based on ${attempts.length} attempt${attempts.length === 1 ? "" : "s"}.`}
        </p>
      </div>

      <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2">
        <Link href="/dashboard/planner" className="card hover:shadow-md">
          <h2 className="font-semibold text-gray-900">Generate a study plan</h2>
          <p className="mt-1 text-sm text-gray-500">
            Enter subjects, goals and your exam date to get an AI schedule.
          </p>
        </Link>
        <Link href="/dashboard/notes" className="card hover:shadow-md">
          <h2 className="font-semibold text-gray-900">Summarize your notes</h2>
          <p className="mt-1 text-sm text-gray-500">
            Paste raw notes and get a summary plus key points.
          </p>
        </Link>
        <Link href="/dashboard/quiz" className="card hover:shadow-md">
          <h2 className="font-semibold text-gray-900">Generate a quiz</h2>
          <p className="mt-1 text-sm text-gray-500">Test yourself with AI-generated MCQs.</p>
        </Link>
        <Link href="/dashboard/flashcards" className="card hover:shadow-md">
          <h2 className="font-semibold text-gray-900">Build flashcards</h2>
          <p className="mt-1 text-sm text-gray-500">Turn any topic into a flippable deck.</p>
        </Link>
      </div>
    </div>
  );
}
