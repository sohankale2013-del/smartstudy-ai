"use client";

import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import type { StudyPlan, StudyScheduleDay } from "@/types/database";

export default function PlannerPage() {
  const [subjects, setSubjects] = useState("");
  const [goal, setGoal] = useState("");
  const [examDate, setExamDate] = useState("");
  const [hoursPerDay, setHoursPerDay] = useState(2);

  const [schedule, setSchedule] = useState<StudyScheduleDay[] | null>(null);
  const [generating, setGenerating] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [saveMessage, setSaveMessage] = useState<string | null>(null);

  const [savedPlans, setSavedPlans] = useState<StudyPlan[]>([]);
  const [loadingPlans, setLoadingPlans] = useState(true);

  async function loadSavedPlans() {
    setLoadingPlans(true);
    const supabase = createClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return;

    const { data, error: fetchError } = await supabase
      .from("study_plans")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false });

    if (!fetchError && data) {
      setSavedPlans(data as StudyPlan[]);
    }
    setLoadingPlans(false);
  }

  useEffect(() => {
    loadSavedPlans();
  }, []);

  async function handleGenerate(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSaveMessage(null);
    setSchedule(null);

    const subjectList = subjects
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean);

    if (subjectList.length === 0 || !goal || !examDate || !hoursPerDay) {
      setError("Please fill in subjects, goal, exam date, and hours per day.");
      return;
    }

    setGenerating(true);
    try {
      const res = await fetch("/api/ai/planner", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ subjects: subjectList, goal, examDate, hoursPerDay }),
      });
      const data = await res.json();

      if (!res.ok) {
        setError(data.error || "Failed to generate a study plan.");
        return;
      }

      setSchedule(data.schedule);
    } catch (err) {
      setError("Network error. Please check your connection and try again.");
    } finally {
      setGenerating(false);
    }
  }

  async function handleSave() {
    if (!schedule) return;
    setSaving(true);
    setSaveMessage(null);
    setError(null);

    try {
      const supabase = createClient();
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) {
        setError("You must be logged in to save a plan.");
        return;
      }

      const subjectList = subjects
        .split(",")
        .map((s) => s.trim())
        .filter(Boolean);

      const { error: insertError } = await supabase.from("study_plans").insert({
        user_id: user.id,
        subjects: subjectList,
        goal,
        exam_date: examDate,
        hours_per_day: hoursPerDay,
        schedule,
      });

      if (insertError) {
        setError(insertError.message);
        return;
      }

      setSaveMessage("Plan saved successfully.");
      await loadSavedPlans();
    } catch (err) {
      setError("Failed to save the plan. Please try again.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-900">AI Study Planner</h1>
      <p className="mt-1 text-sm text-gray-500">
        Tell us your subjects, goal, exam date, and available hours. We'll generate a real
        day-by-day schedule.
      </p>

      <form onSubmit={handleGenerate} className="card mt-6 space-y-4">
        <div>
          <label className="mb-1 block text-sm font-medium text-gray-700">
            Subjects (comma separated)
          </label>
          <input
            className="input-field"
            placeholder="Biology, Calculus, Spanish"
            value={subjects}
            onChange={(e) => setSubjects(e.target.value)}
          />
        </div>
        <div>
          <label className="mb-1 block text-sm font-medium text-gray-700">Goal</label>
          <input
            className="input-field"
            placeholder="Pass with an A, review weak topics, etc."
            value={goal}
            onChange={(e) => setGoal(e.target.value)}
          />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="mb-1 block text-sm font-medium text-gray-700">Exam date</label>
            <input
              type="date"
              className="input-field"
              value={examDate}
              onChange={(e) => setExamDate(e.target.value)}
              min={new Date().toISOString().slice(0, 10)}
            />
          </div>
          <div>
            <label className="mb-1 block text-sm font-medium text-gray-700">
              Hours available per day
            </label>
            <input
              type="number"
              min={0.5}
              max={16}
              step={0.5}
              className="input-field"
              value={hoursPerDay}
              onChange={(e) => setHoursPerDay(parseFloat(e.target.value))}
            />
          </div>
        </div>

        {error && (
          <div className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700" role="alert">
            {error}
          </div>
        )}

        <button type="submit" disabled={generating} className="btn-primary">
          {generating ? "Generating schedule..." : "Generate study plan"}
        </button>
      </form>

      {schedule && (
        <div className="card mt-6">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="font-semibold text-gray-900">Your generated schedule</h2>
            <button onClick={handleSave} disabled={saving} className="btn-primary">
              {saving ? "Saving..." : "Save plan"}
            </button>
          </div>
          {saveMessage && (
            <div className="mb-4 rounded-lg bg-green-50 px-3 py-2 text-sm text-green-700">
              {saveMessage}
            </div>
          )}
          <ScheduleTable schedule={schedule} />
        </div>
      )}

      <div className="mt-8">
        <h2 className="mb-3 text-lg font-semibold text-gray-900">Saved plans</h2>
        {loadingPlans ? (
          <p className="text-sm text-gray-500">Loading saved plans...</p>
        ) : savedPlans.length === 0 ? (
          <p className="text-sm text-gray-500">No saved plans yet.</p>
        ) : (
          <div className="space-y-4">
            {savedPlans.map((plan) => (
              <details key={plan.id} className="card">
                <summary className="cursor-pointer font-medium text-gray-900">
                  {plan.subjects.join(", ")} — exam {plan.exam_date}
                </summary>
                <div className="mt-4">
                  <ScheduleTable schedule={plan.schedule} />
                </div>
              </details>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function ScheduleTable({ schedule }: { schedule: StudyScheduleDay[] }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-left text-sm">
        <thead>
          <tr className="border-b border-gray-200 text-gray-500">
            <th className="py-2 pr-4">Date</th>
            <th className="py-2 pr-4">Subject</th>
            <th className="py-2 pr-4">Topic</th>
            <th className="py-2 pr-4">Duration</th>
            <th className="py-2">Notes</th>
          </tr>
        </thead>
        <tbody>
          {schedule.map((day, i) => (
            <tr key={i} className="border-b border-gray-100">
              <td className="py-2 pr-4 whitespace-nowrap">{day.date}</td>
              <td className="py-2 pr-4">{day.subject}</td>
              <td className="py-2 pr-4">{day.topic}</td>
              <td className="py-2 pr-4 whitespace-nowrap">{day.duration_minutes} min</td>
              <td className="py-2 text-gray-500">{day.notes}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
