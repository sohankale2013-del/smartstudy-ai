"use client";

import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import type { MCQQuestion, Quiz, QuizAttempt } from "@/types/database";

export default function QuizPage() {
  const [topic, setTopic] = useState("");
  const [numQuestions, setNumQuestions] = useState(5);

  const [questions, setQuestions] = useState<MCQQuestion[] | null>(null);
  const [answers, setAnswers] = useState<(number | null)[]>([]);
  const [submitted, setSubmitted] = useState(false);
  const [score, setScore] = useState<number | null>(null);

  const [generating, setGenerating] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [saveMessage, setSaveMessage] = useState<string | null>(null);

  const [history, setHistory] = useState<(QuizAttempt & { quizzes: { topic: string } | null })[]>(
    []
  );
  const [loadingHistory, setLoadingHistory] = useState(true);

  async function loadHistory() {
    setLoadingHistory(true);
    const supabase = createClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return;

    const { data } = await supabase
      .from("quiz_attempts")
      .select("*, quizzes(topic)")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .limit(20);

    if (data) setHistory(data as any);
    setLoadingHistory(false);
  }

  useEffect(() => {
    loadHistory();
  }, []);

  async function handleGenerate() {
    setError(null);
    setSaveMessage(null);
    setQuestions(null);
    setSubmitted(false);
    setScore(null);

    if (topic.trim().length < 3) {
      setError("Please enter a topic or paste some notes.");
      return;
    }

    setGenerating(true);
    try {
      const res = await fetch("/api/ai/quiz", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ topic, numQuestions }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Failed to generate quiz.");
        return;
      }
      setQuestions(data.questions);
      setAnswers(new Array(data.questions.length).fill(null));
    } catch (err) {
      setError("Network error. Please check your connection and try again.");
    } finally {
      setGenerating(false);
    }
  }

  function selectAnswer(qIndex: number, optionIndex: number) {
    if (submitted) return;
    setAnswers((prev) => {
      const copy = [...prev];
      copy[qIndex] = optionIndex;
      return copy;
    });
  }

  function handleSubmitQuiz() {
    if (!questions) return;
    if (answers.some((a) => a === null)) {
      setError("Please answer every question before submitting.");
      return;
    }
    setError(null);
    let correct = 0;
    questions.forEach((q, i) => {
      if (answers[i] === q.correct_index) correct += 1;
    });
    setScore(correct);
    setSubmitted(true);
  }

  async function handleSaveAttempt() {
    if (!questions || score === null) return;
    setSaving(true);
    setSaveMessage(null);
    setError(null);

    try {
      const supabase = createClient();
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) {
        setError("You must be logged in to save.");
        return;
      }

      const { data: quizRow, error: quizError } = await supabase
        .from("quizzes")
        .insert({ user_id: user.id, topic, questions })
        .select()
        .single();

      if (quizError || !quizRow) {
        setError(quizError?.message || "Failed to save quiz.");
        return;
      }

      const { error: attemptError } = await supabase.from("quiz_attempts").insert({
        quiz_id: (quizRow as Quiz).id,
        user_id: user.id,
        answers: answers as number[],
        score,
        total: questions.length,
      });

      if (attemptError) {
        setError(attemptError.message);
        return;
      }

      setSaveMessage("Quiz and result saved.");
      await loadHistory();
    } catch (err) {
      setError("Failed to save. Please try again.");
    } finally {
      setSaving(false);
    }
  }

  function handleRetake() {
    setAnswers(new Array(questions?.length || 0).fill(null));
    setSubmitted(false);
    setScore(null);
    setSaveMessage(null);
  }

  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-900">AI Quiz Generator</h1>
      <p className="mt-1 text-sm text-gray-500">
        Enter a topic or paste notes to generate real multiple-choice questions.
      </p>

      <div className="card mt-6 space-y-4">
        <div>
          <label className="mb-1 block text-sm font-medium text-gray-700">Topic or notes</label>
          <textarea
            className="input-field h-28 resize-none"
            placeholder="e.g. Photosynthesis, World War II causes, or paste your notes"
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
          />
        </div>
        <div className="w-48">
          <label className="mb-1 block text-sm font-medium text-gray-700"># of questions</label>
          <input
            type="number"
            min={3}
            max={15}
            className="input-field"
            value={numQuestions}
            onChange={(e) => setNumQuestions(parseInt(e.target.value, 10))}
          />
        </div>
        {error && (
          <div className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700" role="alert">
            {error}
          </div>
        )}
        <button onClick={handleGenerate} disabled={generating} className="btn-primary">
          {generating ? "Generating quiz..." : "Generate quiz"}
        </button>
      </div>

      {questions && (
        <div className="card mt-6">
          <div className="space-y-6">
            {questions.map((q, qi) => (
              <div key={qi}>
                <p className="font-medium text-gray-900">
                  {qi + 1}. {q.question}
                </p>
                <div className="mt-2 space-y-2">
                  {q.options.map((opt, oi) => {
                    const isSelected = answers[qi] === oi;
                    const isCorrect = submitted && oi === q.correct_index;
                    const isWrongSelected = submitted && isSelected && oi !== q.correct_index;
                    return (
                      <button
                        key={oi}
                        type="button"
                        onClick={() => selectAnswer(qi, oi)}
                        className={`block w-full rounded-lg border px-3 py-2 text-left text-sm transition ${
                          isCorrect
                            ? "border-green-400 bg-green-50 text-green-800"
                            : isWrongSelected
                            ? "border-red-400 bg-red-50 text-red-800"
                            : isSelected
                            ? "border-brand-500 bg-brand-50"
                            : "border-gray-200 hover:bg-gray-50"
                        }`}
                      >
                        {opt}
                      </button>
                    );
                  })}
                </div>
                {submitted && (
                  <p className="mt-2 text-xs text-gray-500">{q.explanation}</p>
                )}
              </div>
            ))}
          </div>

          <div className="mt-6 flex items-center gap-3">
            {!submitted ? (
              <button onClick={handleSubmitQuiz} className="btn-primary">
                Submit answers
              </button>
            ) : (
              <>
                <p className="font-semibold text-gray-900">
                  Score: {score} / {questions.length}
                </p>
                <button onClick={handleSaveAttempt} disabled={saving} className="btn-primary">
                  {saving ? "Saving..." : "Save result"}
                </button>
                <button onClick={handleRetake} className="btn-secondary">
                  Retake
                </button>
              </>
            )}
          </div>
          {saveMessage && (
            <div className="mt-4 rounded-lg bg-green-50 px-3 py-2 text-sm text-green-700">
              {saveMessage}
            </div>
          )}
        </div>
      )}

      <div className="mt-8">
        <h2 className="mb-3 text-lg font-semibold text-gray-900">Past attempts</h2>
        {loadingHistory ? (
          <p className="text-sm text-gray-500">Loading...</p>
        ) : history.length === 0 ? (
          <p className="text-sm text-gray-500">No quiz attempts yet.</p>
        ) : (
          <div className="space-y-2">
            {history.map((attempt) => (
              <div key={attempt.id} className="card flex items-center justify-between py-3">
                <span className="text-sm text-gray-700">
                  {attempt.quizzes?.topic?.slice(0, 60) || "Quiz"}
                </span>
                <span className="text-sm font-medium text-gray-900">
                  {attempt.score} / {attempt.total}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
