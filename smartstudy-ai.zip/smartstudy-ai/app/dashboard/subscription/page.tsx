"use client";

import { Suspense, useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

export default function SubscriptionPage() {
  return (
    <Suspense fallback={<p className="text-sm text-gray-500">Loading...</p>}>
      <SubscriptionContent />
    </Suspense>
  );
}

function SubscriptionContent() {
  const searchParams = useSearchParams();
  const [plan, setPlan] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [upgrading, setUpgrading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const success = searchParams.get("success") === "true";
  const canceled = searchParams.get("canceled") === "true";

  useEffect(() => {
    async function loadPlan() {
      const supabase = createClient();
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) return;

      const { data } = await supabase.from("profiles").select("plan").eq("id", user.id).single();
      setPlan(data?.plan ?? "free");
      setLoading(false);
    }
    loadPlan();
  }, []);

  async function handleUpgrade() {
    setUpgrading(true);
    setError(null);
    try {
      const res = await fetch("/api/stripe/checkout", { method: "POST" });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Failed to start checkout.");
        return;
      }
      window.location.href = data.url;
    } catch (err) {
      setError("Network error. Please try again.");
    } finally {
      setUpgrading(false);
    }
  }

  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-900">Subscription</h1>
      <p className="mt-1 text-sm text-gray-500">Manage your SmartStudy AI plan.</p>

      {success && (
        <div className="mt-4 rounded-lg bg-green-50 px-3 py-2 text-sm text-green-700">
          Payment successful! Your plan will update once Stripe confirms the subscription.
        </div>
      )}
      {canceled && (
        <div className="mt-4 rounded-lg bg-yellow-50 px-3 py-2 text-sm text-yellow-700">
          Checkout was canceled. No charge was made.
        </div>
      )}
      {error && (
        <div className="mt-4 rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700" role="alert">
          {error}
        </div>
      )}

      <div className="mt-6 grid grid-cols-1 gap-6 sm:grid-cols-2">
        <div className="card">
          <h2 className="text-lg font-semibold text-gray-900">Free</h2>
          <p className="mt-1 text-3xl font-bold text-gray-900">$0</p>
          <ul className="mt-4 space-y-2 text-sm text-gray-600">
            <li>✓ AI Study Planner</li>
            <li>✓ Notes Summarizer</li>
            <li>✓ Quiz Generator</li>
            <li>✓ Flashcards</li>
            <li>✓ Limited monthly AI generations</li>
          </ul>
          {!loading && plan === "free" && (
            <p className="mt-4 rounded-lg bg-gray-100 px-3 py-2 text-center text-sm font-medium text-gray-700">
              Current plan
            </p>
          )}
        </div>

        <div className="card border-brand-200">
          <h2 className="text-lg font-semibold text-gray-900">Pro</h2>
          <p className="mt-1 text-3xl font-bold text-gray-900">
            $9<span className="text-base font-normal text-gray-500">/mo</span>
          </p>
          <ul className="mt-4 space-y-2 text-sm text-gray-600">
            <li>✓ Everything in Free</li>
            <li>✓ Unlimited AI generations</li>
            <li>✓ Priority AI response times</li>
            <li>✓ Unlimited saved plans, decks, and quizzes</li>
          </ul>
          {!loading && plan === "pro" ? (
            <p className="mt-4 rounded-lg bg-brand-50 px-3 py-2 text-center text-sm font-medium text-brand-700">
              Current plan
            </p>
          ) : (
            <button onClick={handleUpgrade} disabled={upgrading} className="btn-primary mt-4 w-full">
              {upgrading ? "Redirecting to checkout..." : "Upgrade to Pro"}
            </button>
          )}
        </div>
      </div>

      <p className="mt-6 text-xs text-gray-400">
        Payments are processed securely by Stripe. Your plan updates automatically once Stripe
        confirms your subscription via webhook.
      </p>
    </div>
  );
}
