import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "SmartStudy AI",
  description: "AI-powered study planner, notes summarizer, quiz and flashcard generator.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
