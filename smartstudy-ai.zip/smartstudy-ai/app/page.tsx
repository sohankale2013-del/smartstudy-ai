import Link from "next/link";
import { redirect } from "next/navigation";
import { createServerSupabaseClient } from "@/lib/supabase/server";

export default async function HomePage() {
  let user = null;
  try {
    const supabase = createServerSupabaseClient();
    const {
      data: { user: sessionUser },
    } = await supabase.auth.getUser();
    user = sessionUser;
  } catch {
    // Supabase not configured yet — still show the landing page.
  }

  if (user) {
    redirect("/dashboard");
  }

  return (
    <main className="flex min-h-screen flex-col items-center justify-center bg-gradient-to-b from-brand-50 to-white px-6 text-center">
      <span className="mb-4 rounded-full bg-brand-100 px-3 py-1 text-xs font-semibold text-brand-700">
        AI Study Assistant
      </span>
      <h1 className="max-w-2xl text-4xl font-bold tracking-tight text-gray-900 sm:text-5xl">
        Study smarter with SmartStudy AI
      </h1>
      <p className="mt-4 max-w-xl text-lg text-gray-600">
        Generate study plans, summarize notes, create quizzes, and build flashcards — all
        powered by real AI, saved to your account.
      </p>
      <div className="mt-8 flex gap-4">
        <Link href="/signup" className="btn-primary px-6 py-3 text-base">
          Get started free
        </Link>
        <Link href="/login" className="btn-secondary px-6 py-3 text-base">
          Log in
        </Link>
      </div>
    </main>
  );
}
