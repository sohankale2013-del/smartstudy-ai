"use client";

import { useState } from "react";
import type { Flashcard } from "@/types/database";

export default function FlashcardView({ card }: { card: Flashcard }) {
  const [flipped, setFlipped] = useState(false);

  return (
    <div
      className={`flip-card h-40 cursor-pointer ${flipped ? "flipped" : ""}`}
      onClick={() => setFlipped((f) => !f)}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") setFlipped((f) => !f);
      }}
    >
      <div className="flip-card-inner">
        <div className="flip-card-front flex items-center justify-center rounded-xl border border-gray-200 bg-white p-4 text-center shadow-sm">
          <p className="text-sm font-medium text-gray-900">{card.front}</p>
        </div>
        <div className="flip-card-back flex items-center justify-center rounded-xl border border-brand-200 bg-brand-50 p-4 text-center shadow-sm">
          <p className="text-sm text-gray-800">{card.back}</p>
        </div>
      </div>
    </div>
  );
}
