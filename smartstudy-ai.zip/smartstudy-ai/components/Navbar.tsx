"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useState } from "react";

const links = [
  { href: "/dashboard", label: "Overview" },
  { href: "/dashboard/planner", label: "Study Planner" },
  { href: "/dashboard/notes", label: "Notes Summarizer" },
  { href: "/dashboard/quiz", label: "Quiz Generator" },
  { href: "/dashboard/flashcards", label: "Flashcards" },
  { href: "/dashboard/subscription", label: "Subscription" },
];

export default function Navbar({ email, plan }: { email: string; plan: string }) {
  const pathname = usePathname();
  const router = useRouter();
  const [signingOut, setSigningOut] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSignOut() {
    setSigningOut(true);
    setError(null);
    try {
      const res = await fetch("/api/auth/signout", { method: "POST" });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Failed to sign out.");
        setSigningOut(false);
        return;
      }
      router.push("/login");
      router.refresh();
    } catch (err) {
      setError("Failed to sign out. Check your connection.");
      setSigningOut(false);
    }
  }

  return (
    <nav className="flex min-h-screen w-64 flex-col border-r border-gray-200 bg-white p-4">
      <Link href="/dashboard" className="mb-6 px-2 text-lg font-bold text-brand-600">
        SmartStudy AI
      </Link>

      <div className="flex-1 space-y-1">
        {links.map((link) => (
          <Link
            key={link.href}
            href={link.href}
            className={`block rounded-lg px-3 py-2 text-sm font-medium transition ${
              pathname === link.href
                ? "bg-brand-50 text-brand-700"
                : "text-gray-600 hover:bg-gray-50"
            }`}
          >
            {link.label}
          </Link>
        ))}
      </div>

      <div className="border-t border-gray-200 pt-4">
        <p className="truncate px-2 text-xs text-gray-500">{email}</p>
        <p className="mb-2 px-2 text-xs font-medium uppercase tracking-wide text-brand-600">
          {plan} plan
        </p>
        {error && <p className="mb-2 px-2 text-xs text-red-600">{error}</p>}
        <button onClick={handleSignOut} disabled={signingOut} className="btn-secondary w-full">
          {signingOut ? "Signing out..." : "Sign out"}
        </button>
      </div>
    </nav>
  );
}
