import { GoogleGenerativeAI } from "@google/generative-ai";

export class GeminiConfigError extends Error {}
export class GeminiGenerationError extends Error {}

function getModel() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new GeminiConfigError(
      "GEMINI_API_KEY is not set on the server. Add it to .env.local and restart the server."
    );
  }
  const genAI = new GoogleGenerativeAI(apiKey);
  return genAI.getGenerativeModel({
    model: "gemini-1.5-flash",
    generationConfig: {
      temperature: 0.7,
      responseMimeType: "application/json",
    },
  });
}

/**
 * Sends a prompt to Gemini and parses the response as JSON.
 * Throws GeminiGenerationError with a user-safe message on any failure,
 * so callers can return a proper HTTP error instead of pretending success.
 */
export async function generateJSON<T>(prompt: string): Promise<T> {
  const model = getModel();

  let rawText: string;
  try {
    const result = await model.generateContent(prompt);
    rawText = result.response.text();
  } catch (err) {
    console.error("Gemini API call failed:", err);
    throw new GeminiGenerationError(
      "The AI service failed to respond. Please try again in a moment."
    );
  }

  const cleaned = rawText
    .trim()
    .replace(/^```json/i, "")
    .replace(/^```/, "")
    .replace(/```$/, "")
    .trim();

  try {
    return JSON.parse(cleaned) as T;
  } catch (err) {
    console.error("Gemini returned non-JSON output:", rawText);
    throw new GeminiGenerationError(
      "The AI returned an unexpected response format. Please try again."
    );
  }
}
