-- Run this entire file in Supabase SQL Editor (Project -> SQL Editor -> New query)

-- 1. Profiles ---------------------------------------------------------------
create table if not exists public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  email text not null,
  full_name text,
  plan text not null default 'free' check (plan in ('free', 'pro')),
  stripe_customer_id text,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;

create policy "Users can view own profile"
  on public.profiles for select
  using (auth.uid() = id);

create policy "Users can update own profile"
  on public.profiles for update
  using (auth.uid() = id);

-- Auto-create a profile row whenever a new auth user signs up
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, email, full_name)
  values (new.id, new.email, new.raw_user_meta_data->>'full_name')
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- 2. Study plans --------------------------------------------------------------
create table if not exists public.study_plans (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  subjects text[] not null,
  goal text not null,
  exam_date date not null,
  hours_per_day numeric not null,
  schedule jsonb not null,
  created_at timestamptz not null default now()
);

alter table public.study_plans enable row level security;

create policy "Users manage own study plans"
  on public.study_plans for all
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

-- 3. Notes summaries ------------------------------------------------------------
create table if not exists public.notes_summaries (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  original_notes text not null,
  summary text not null,
  key_points text[] not null default '{}',
  revision_notes text[] not null default '{}',
  created_at timestamptz not null default now()
);

alter table public.notes_summaries enable row level security;

create policy "Users manage own notes summaries"
  on public.notes_summaries for all
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

-- 4. Quizzes + attempts ---------------------------------------------------------
create table if not exists public.quizzes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  topic text not null,
  questions jsonb not null,
  created_at timestamptz not null default now()
);

alter table public.quizzes enable row level security;

create policy "Users manage own quizzes"
  on public.quizzes for all
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

create table if not exists public.quiz_attempts (
  id uuid primary key default gen_random_uuid(),
  quiz_id uuid not null references public.quizzes (id) on delete cascade,
  user_id uuid not null references auth.users (id) on delete cascade,
  answers integer[] not null,
  score integer not null,
  total integer not null,
  created_at timestamptz not null default now()
);

alter table public.quiz_attempts enable row level security;

create policy "Users manage own quiz attempts"
  on public.quiz_attempts for all
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

-- 5. Flashcard decks --------------------------------------------------------------
create table if not exists public.flashcard_decks (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  title text not null,
  cards jsonb not null,
  created_at timestamptz not null default now()
);

alter table public.flashcard_decks enable row level security;

create policy "Users manage own flashcard decks"
  on public.flashcard_decks for all
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

-- 6. Helpful indexes ----------------------------------------------------------------
create index if not exists idx_study_plans_user on public.study_plans (user_id, created_at desc);
create index if not exists idx_notes_summaries_user on public.notes_summaries (user_id, created_at desc);
create index if not exists idx_quizzes_user on public.quizzes (user_id, created_at desc);
create index if not exists idx_quiz_attempts_user on public.quiz_attempts (user_id, created_at desc);
create index if not exists idx_flashcard_decks_user on public.flashcard_decks (user_id, created_at desc);
