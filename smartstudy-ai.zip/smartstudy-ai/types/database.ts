export type Plan = "free" | "pro";

export interface Profile {
  id: string;
  email: string;
  full_name: string | null;
  plan: Plan;
  stripe_customer_id: string | null;
  created_at: string;
}

export interface StudyPlan {
  id: string;
  user_id: string;
  subjects: string[];
  goal: string;
  exam_date: string;
  hours_per_day: number;
  schedule: StudyScheduleDay[];
  created_at: string;
}

export interface StudyScheduleDay {
  date: string;
  subject: string;
  topic: string;
  duration_minutes: number;
  notes: string;
}

export interface NotesSummary {
  id: string;
  user_id: string;
  original_notes: string;
  summary: string;
  key_points: string[];
  revision_notes: string[];
  created_at: string;
}

export interface MCQQuestion {
  question: string;
  options: string[];
  correct_index: number;
  explanation: string;
}

export interface Quiz {
  id: string;
  user_id: string;
  topic: string;
  questions: MCQQuestion[];
  created_at: string;
}

export interface QuizAttempt {
  id: string;
  quiz_id: string;
  user_id: string;
  answers: number[];
  score: number;
  total: number;
  created_at: string;
}

export interface Flashcard {
  front: string;
  back: string;
}

export interface FlashcardDeck {
  id: string;
  user_id: string;
  title: string;
  cards: Flashcard[];
  created_at: string;
}

// Minimal shape used by @supabase/ssr generics. Kept loose on purpose;
// extend with `supabase gen types typescript` once your project is live.
export interface Database {
  public: {
    Tables: {
      profiles: { Row: Profile; Insert: Partial<Profile>; Update: Partial<Profile> };
      study_plans: { Row: StudyPlan; Insert: Partial<StudyPlan>; Update: Partial<StudyPlan> };
      notes_summaries: { Row: NotesSummary; Insert: Partial<NotesSummary>; Update: Partial<NotesSummary> };
      quizzes: { Row: Quiz; Insert: Partial<Quiz>; Update: Partial<Quiz> };
      quiz_attempts: { Row: QuizAttempt; Insert: Partial<QuizAttempt>; Update: Partial<QuizAttempt> };
      flashcard_decks: { Row: FlashcardDeck; Insert: Partial<FlashcardDeck>; Update: Partial<FlashcardDeck> };
    };
  };
}
